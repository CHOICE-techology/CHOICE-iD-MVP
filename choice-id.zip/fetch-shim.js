const fetch = window.fetch;
const Request = window.Request;
const Response = window.Response;
const Headers = window.Headers;

export { fetch, Request, Response, Headers };
export default fetch;
